#!/bin/bash
echo "RUN.SH started"
which python
python --version
echo "Attempting to run main.py"
python src/main.py
echo "Done"
